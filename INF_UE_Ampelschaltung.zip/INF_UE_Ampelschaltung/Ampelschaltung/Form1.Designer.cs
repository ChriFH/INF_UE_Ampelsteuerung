﻿namespace Ampelschaltung
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txt_Red = new TextBox();
            txt_Green = new TextBox();
            lbl_Red = new Label();
            lbl_Green = new Label();
            pan_Car = new Panel();
            pan_TrafficLight = new Panel();
            rad_Man = new RadioButton();
            rad_Auto = new RadioButton();
            tmr_33ms = new System.Windows.Forms.Timer(components);
            btn_Red = new Button();
            btn_Green = new Button();
            pan_Line = new Panel();
            lbl_Time = new Label();
            lbl_s = new Label();
            lbl_s1 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // txt_Red
            // 
            txt_Red.Location = new Point(138, 23);
            txt_Red.Margin = new Padding(2);
            txt_Red.Name = "txt_Red";
            txt_Red.Size = new Size(38, 23);
            txt_Red.TabIndex = 0;
            txt_Red.Text = "6";
            txt_Red.TextChanged += txt_Red_TextChanged;
            // 
            // txt_Green
            // 
            txt_Green.Location = new Point(138, 58);
            txt_Green.Margin = new Padding(2);
            txt_Green.Name = "txt_Green";
            txt_Green.Size = new Size(38, 23);
            txt_Green.TabIndex = 1;
            txt_Green.Text = "3";
            txt_Green.TextChanged += txt_Green_TextChanged;
            // 
            // lbl_Red
            // 
            lbl_Red.AutoSize = true;
            lbl_Red.Location = new Point(213, 28);
            lbl_Red.Margin = new Padding(2, 0, 2, 0);
            lbl_Red.Name = "lbl_Red";
            lbl_Red.Size = new Size(90, 15);
            lbl_Red.TabIndex = 2;
            lbl_Red.Text = "Dauer Rotphase";
            // 
            // lbl_Green
            // 
            lbl_Green.AutoSize = true;
            lbl_Green.Location = new Point(213, 61);
            lbl_Green.Margin = new Padding(2, 0, 2, 0);
            lbl_Green.Name = "lbl_Green";
            lbl_Green.Size = new Size(98, 15);
            lbl_Green.TabIndex = 3;
            lbl_Green.Text = "Dauer Grünphase";
            // 
            // pan_Car
            // 
            pan_Car.BackColor = Color.Blue;
            pan_Car.Location = new Point(99, 320);
            pan_Car.Margin = new Padding(2);
            pan_Car.Name = "pan_Car";
            pan_Car.Size = new Size(70, 30);
            pan_Car.TabIndex = 4;
            // 
            // pan_TrafficLight
            // 
            pan_TrafficLight.BackColor = Color.Red;
            pan_TrafficLight.Location = new Point(646, 147);
            pan_TrafficLight.Margin = new Padding(2);
            pan_TrafficLight.Name = "pan_TrafficLight";
            pan_TrafficLight.Size = new Size(35, 60);
            pan_TrafficLight.TabIndex = 5;
            // 
            // rad_Man
            // 
            rad_Man.AutoSize = true;
            rad_Man.Location = new Point(405, 29);
            rad_Man.Margin = new Padding(2);
            rad_Man.Name = "rad_Man";
            rad_Man.Size = new Size(130, 19);
            rad_Man.TabIndex = 6;
            rad_Man.Text = "Manuelle Schaltung";
            rad_Man.UseVisualStyleBackColor = true;
            // 
            // rad_Auto
            // 
            rad_Auto.AutoSize = true;
            rad_Auto.Checked = true;
            rad_Auto.Location = new Point(405, 50);
            rad_Auto.Margin = new Padding(2);
            rad_Auto.Name = "rad_Auto";
            rad_Auto.Size = new Size(155, 19);
            rad_Auto.TabIndex = 7;
            rad_Auto.TabStop = true;
            rad_Auto.Text = "Automatische Schaltung";
            rad_Auto.UseVisualStyleBackColor = true;
            // 
            // tmr_33ms
            // 
            tmr_33ms.Interval = 33;
            tmr_33ms.Tick += tmr_33ms_Tick;
            // 
            // btn_Red
            // 
            btn_Red.Location = new Point(646, 29);
            btn_Red.Margin = new Padding(2);
            btn_Red.Name = "btn_Red";
            btn_Red.Size = new Size(123, 20);
            btn_Red.TabIndex = 8;
            btn_Red.Text = "Schalte auf Rot";
            btn_Red.UseVisualStyleBackColor = true;
            btn_Red.Click += btn_Red_Click;
            // 
            // btn_Green
            // 
            btn_Green.Location = new Point(647, 61);
            btn_Green.Margin = new Padding(2);
            btn_Green.Name = "btn_Green";
            btn_Green.Size = new Size(122, 20);
            btn_Green.TabIndex = 9;
            btn_Green.Text = "Schalte auf Grün";
            btn_Green.UseVisualStyleBackColor = true;
            btn_Green.Click += btn_Green_Click;
            // 
            // pan_Line
            // 
            pan_Line.BackColor = Color.Black;
            pan_Line.Location = new Point(594, 0);
            pan_Line.Margin = new Padding(2);
            pan_Line.Name = "pan_Line";
            pan_Line.Size = new Size(14, 480);
            pan_Line.TabIndex = 10;
            // 
            // lbl_Time
            // 
            lbl_Time.AutoSize = true;
            lbl_Time.Location = new Point(50, 50);
            lbl_Time.Margin = new Padding(2, 0, 2, 0);
            lbl_Time.Name = "lbl_Time";
            lbl_Time.Size = new Size(12, 15);
            lbl_Time.TabIndex = 11;
            lbl_Time.Text = "?";
            // 
            // lbl_s
            // 
            lbl_s.AutoSize = true;
            lbl_s.Location = new Point(178, 28);
            lbl_s.Name = "lbl_s";
            lbl_s.Size = new Size(12, 15);
            lbl_s.TabIndex = 12;
            lbl_s.Text = "s";
            // 
            // lbl_s1
            // 
            lbl_s1.AutoSize = true;
            lbl_s1.Location = new Point(179, 63);
            lbl_s1.Name = "lbl_s1";
            lbl_s1.Size = new Size(12, 15);
            lbl_s1.TabIndex = 13;
            lbl_s1.Text = "s";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(33, 29);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 14;
            label1.Text = "Stoppuhr";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(906, 452);
            Controls.Add(label1);
            Controls.Add(lbl_s1);
            Controls.Add(lbl_s);
            Controls.Add(pan_Car);
            Controls.Add(lbl_Time);
            Controls.Add(pan_Line);
            Controls.Add(btn_Green);
            Controls.Add(btn_Red);
            Controls.Add(rad_Auto);
            Controls.Add(rad_Man);
            Controls.Add(pan_TrafficLight);
            Controls.Add(lbl_Green);
            Controls.Add(lbl_Red);
            Controls.Add(txt_Green);
            Controls.Add(txt_Red);
            Margin = new Padding(2);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_Red;
        private TextBox txt_Green;
        private Label lbl_Red;
        private Label lbl_Green;
        private Panel pan_Car;
        private Panel pan_TrafficLight;
        private RadioButton rad_Man;
        private RadioButton rad_Auto;
        private System.Windows.Forms.Timer tmr_33ms;
        private Button btn_Red;
        private Button btn_Green;
        private Panel pan_Line;
        private Label lbl_Time;
        private Label lbl_s;
        private Label lbl_s1;
        private Label label1;
    }
}
