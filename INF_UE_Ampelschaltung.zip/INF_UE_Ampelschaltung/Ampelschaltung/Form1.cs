using System.Diagnostics;

namespace Ampelschaltung
{
    public partial class Form1 : Form
    {
        double RedPhaseDuration = 0;                            //declare variable for red phase duration
        double GreenPhaseDuration = 0;                          //declare varibale for green phase duration
        double ElapsedSecondsLight = 0;                         //declare varibale for elapsed seconds

        Stopwatch StopwatchLightPhase = new Stopwatch();        //declare stopwatch for red phase

        //this function initilizes the form and is only executed once when the program starts
        public Form1()
        {
            InitializeComponent();

            tmr_33ms.Enabled = true;                                //enable timer
            StopwatchLightPhase.Start();                            //Start stopwatch for light phases (1. red, 2. green)
            RedPhaseDuration = Convert.ToDouble(txt_Red.Text);      //set initial red phase duration of text box input
            GreenPhaseDuration = Convert.ToDouble(txt_Green.Text);  //set initial green phase duration of text box input
        }

        //button green is pressed (double click on button to get this function)
        private void btn_Green_Click(object sender, EventArgs e)
        {
            if (rad_Man.Checked)                                //if radio button manual is checked
            {
                pan_TrafficLight.BackColor = Color.Green;       //change traffic light into green
            }
        }

        //button red is pressed (double click on button to get this function)
        private void btn_Red_Click(object sender, EventArgs e)
        {
            if (rad_Man.Checked)                                //if radio button manual is checked
            {
                pan_TrafficLight.BackColor = Color.Red;         //change traffic light into red
            }
        }

        /******************************************************************************************************/
        //timer function (double click on timer to get this function)
        private void tmr_33ms_Tick(object sender, EventArgs e)
        {
            CarMovement();                                                            //call function CarMovement()
            lbl_Time.Text = ElapsedSecondsLight.ToString();                           //write elapsed time on lable

            ElapsedSecondsLight = StopwatchLightPhase.ElapsedMilliseconds / 1000;     //convert stopwatch time

            //switch to green light
            if (rad_Auto.Checked && pan_TrafficLight.BackColor == Color.Red           //if radio button auto and background color is red
                && ElapsedSecondsLight >= RedPhaseDuration)                           //and elapsed seconds exceeds the set red phase duration
            {
                pan_TrafficLight.BackColor = Color.Green;                             //change background color to green                                       
            }

            //switch to red light
            if (rad_Auto.Checked && pan_TrafficLight.BackColor == Color.Green         //if radio button auto and background color is green
                && ElapsedSecondsLight >= RedPhaseDuration + GreenPhaseDuration)      //and elapsed seconds exceeds the set green phase duration
            {
                pan_TrafficLight.BackColor = Color.Red;                               //change background color to green
                StopwatchLightPhase.Restart();                                        //restart stopwatch
            }
        }


        /******************************************************************************************************/
        //function for car movement (driving and stopping at red light)
        private void CarMovement()
        {
            //check if background color of road light is red
            if (pan_TrafficLight.BackColor == Color.Red)
            {
                //stop car at the stop line (10 px stop area in front of the line)
                if (pan_Car.Left + pan_Car.Width > pan_Line.Left - 10 &&             //car is 10px in front of the stop line 
                     pan_Car.Left + pan_Car.Width < pan_Line.Left)                   //car is exactly in front of the stop line
                {
                    pan_Car.Left += 0;
                }
                else
                {
                    pan_Car.Left += 10;     //move car
                }
            }
            else
            {
                pan_Car.Left += 10;         //move car
            }

            //set car to the left side of the window if it reaches the right side 
            if (pan_Car.Left + pan_Car.Width > ClientSize.Width)
            {
                pan_Car.Left = 0;
            }
        }

        //function for checking the input value of a texbox to be between 1 and 200
        private double CheckValue(TextBox textBox)
        {
            double outputNumber = 0;        //declare output variable
            
            if (double.TryParse(textBox.Text, out double checkNumber))      //check if input value is a numeric value within the double range
            {
                if (checkNumber > 0 && checkNumber < 200)     //if input value is between 1 and 200
                {
                    outputNumber = checkNumber;               //write number on red phase variable
                }
                else
                {
                    outputNumber = 1;        //if input is not between 1 and 200 set value to 1
                    MessageBox.Show("Die Eingabe muss eine Zahl zwischen 1 und 200 sein!");      //write message if value is not a number
                }
            }
            else
            {
                outputNumber = 1;           //if input is not a number set value to 1
                MessageBox.Show("Die Eingabe muss eine Zahl sein!");      //write message if value is not a number
            }
            return outputNumber;
        }


        /******************************************************************************************************/
        //function when text is changed (double click on textbox to get this function)
        private void txt_Red_TextChanged(object sender, EventArgs e)
        {
            RedPhaseDuration = CheckValue(txt_Red);     //call function to check value range of textbox input and write value on variable
        }

        //function when text is changed (double click on textbox to get this function)
        private void txt_Green_TextChanged(object sender, EventArgs e)
        {
            GreenPhaseDuration = CheckValue(txt_Green);     //call function to check value range of textbox input and write value on variable
        }
    }
}